export const CONTEXT_MENU_ITEM_ID = "classify-selection";
export const ACTION_NAME = "classify";
