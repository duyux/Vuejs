---
title: Segment Anything WebGPU
emoji: ⚡
colorFrom: blue
colorTo: yellow
sdk: static
pinned: false
models:
  - Xenova/slimsam-77-uniform
license: apache-2.0
short_description: In-browser image segmentation w/ 🤗 Transformers.js
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
