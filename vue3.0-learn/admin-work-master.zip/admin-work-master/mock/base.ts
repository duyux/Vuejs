export const baseData = {
  code: 200,
  data: '',
  msg: '获取数据成功',
}
