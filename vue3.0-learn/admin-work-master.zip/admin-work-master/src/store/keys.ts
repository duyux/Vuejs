export const LAYOUT = import('@/components/Layout.vue')
