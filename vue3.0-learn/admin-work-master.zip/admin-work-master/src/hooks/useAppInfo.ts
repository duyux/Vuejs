import packageInfo from '../../package.json'
export default function useAppInfo() {
  return packageInfo
}
