import { get } from '../api/http'
export default function usePost() {
  return get
}
