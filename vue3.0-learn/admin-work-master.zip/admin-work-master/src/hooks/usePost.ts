import { post } from '../api/http'
export default function usePost() {
  return post
}
