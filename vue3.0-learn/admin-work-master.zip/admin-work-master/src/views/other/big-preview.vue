<template>
  <n-card title="大图预览（要相信世界上美好的事总会发生在你的身上）" segmented>
    <n-image-group>
      <n-space align="center" justify="center">
        <n-image width="200" src="http://qingqingxuan.gitee.io/img/beautiful-1.jpg" />
        <n-image width="200" src="http://qingqingxuan.gitee.io/img/beautiful-2.jpeg" />
        <n-image width="200" src="http://qingqingxuan.gitee.io/img/beautiful-3.jpeg" />
      </n-space>
    </n-image-group>
  </n-card>
</template>

<script lang="ts" setup></script>
