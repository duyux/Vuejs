import YwzTable from './src/YwzTable.vue'
export default YwzTable
