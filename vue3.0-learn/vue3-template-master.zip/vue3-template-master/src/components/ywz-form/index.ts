import YwzForm from './src/NavMenu.vue'

export default YwzForm
