const router = {
  name: 'Echarts',
  path: '/main/visualization/echarts',
  component: () => import('/@/views/main/visualization/EchartsPage.vue'),
}
export default router
