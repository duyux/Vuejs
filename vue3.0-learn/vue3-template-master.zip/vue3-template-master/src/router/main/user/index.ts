const router = {
  name: 'UserManger',
  path: '/main/system/user',
  component: () => import('/@/views/main/system/UserManger.vue'),
}
export default router
