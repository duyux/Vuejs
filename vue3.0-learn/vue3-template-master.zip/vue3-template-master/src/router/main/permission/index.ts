const router = {
  name: 'PermissionManger',
  path: '/main/system/permission',
  component: () => import('/@/views/main/system/PermissionManger.vue'),
}
export default router
