const router = {
  name: 'RoleManger',
  path: '/main/system/role',
  component: () => import('/@/views/main/system/RoleManger.vue'),
}
export default router
