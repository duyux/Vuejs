const router = {
  name: 'WorkPlace',
  path: '/main/dashboard/workplace',
  component: () => import('/@/views/main/dashboard/WorkPlace.vue'),
}
export default router
