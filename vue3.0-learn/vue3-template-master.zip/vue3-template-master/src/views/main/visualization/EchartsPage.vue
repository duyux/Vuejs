<script setup lang="ts"></script>

<template>
  <div>Echarts</div>
</template>

<style scoped></style>
