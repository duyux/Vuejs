export const ACCESS_TOKEN: string = "GEEKER_ACCESS_TOKEN";
export const USER_INFO: string = "GEEKER_USER_INFO";
