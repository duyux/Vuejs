<template>
	<div class="home flx-center">
		<img class="home-bg" src="@/assets/images/welcome.png" alt="welcome" />
	</div>
</template>

<script setup lang="ts" name="home">
import { ResultEnum } from "@/enums/httpEnum";
console.log(ResultEnum);
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
