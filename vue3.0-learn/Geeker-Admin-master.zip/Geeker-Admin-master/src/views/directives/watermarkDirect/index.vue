<template>
	<div class="content-box" v-waterMarker="{ text: 'Watermark Direct', textColor: 'rgba(180, 180, 180, 0.6)' }">
		<span class="text">水印指令 🍇🍇🍇🍓🍓🍓</span>
	</div>
</template>

<script setup lang="ts" name="watermarkDirect"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
