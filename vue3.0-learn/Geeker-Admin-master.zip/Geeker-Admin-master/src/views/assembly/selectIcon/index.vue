<template>
	<div class="content-box">
		<span class="text">Icon 选择 🍓🍇🍈🍉</span>
	</div>
</template>

<script setup lang="ts" name="selectIcon"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
