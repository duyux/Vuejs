<template>
	<div class="content-box">
		<span class="text">
			掘金文档：
			<a href="https://juejin.cn/post/7080820051422478366" target="_blank">https://juejin.cn/post/7080820051422478366</a> 🍒🍉🍊
		</span>
	</div>
</template>

<script setup lang="ts" name="juejin"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
