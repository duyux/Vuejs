export const steps = () => [{
    element: "#guide",
    popover: {
      title: "菜单栏",
      description: "Body of the popover",
      position: "left",
    },
  },
  {
    element: "#breadcrumb",
    popover: {
      title: "标签页",
      description: "",
      position: "bottom",
    },
  },
  {
    element: "#screenFul",
    popover: {
      title: "全屏",
      description: "Body of the popover",
      position: "bottom",
    },
  },
];