<template>
  <div class="content-box" style="height: 100%">
    <iframe src="https://cn.bing.com/" frameborder="0" class="full-iframe"></iframe>
  </div>
</template>

<style lang="scss" scoped>
.content-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  background-color: #fff;
}
.full-iframe {
  // margin-top: 2.5%;
  width: 100%;
  height: 100%;
}
</style>
