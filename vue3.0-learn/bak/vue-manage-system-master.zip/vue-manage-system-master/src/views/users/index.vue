<template>
  <el-card>
    <div>💐🌸💮🏵️🌹🌺🌻</div>
  </el-card>
</template>

<script setup></script>

<style lang="scss" scoped></style>
