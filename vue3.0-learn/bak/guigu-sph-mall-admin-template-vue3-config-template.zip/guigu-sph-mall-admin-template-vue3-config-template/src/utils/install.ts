/*
 * @Author: 朽木白
 * @Date: 2023-02-05 15:33:55
 * @LastEditors: 1547702880@@qq.com
 * @LastEditTime: 2023-02-05 16:09:13
 * @Description: 注册组件方法
 */

import type { App, Plugin } from 'vue'
