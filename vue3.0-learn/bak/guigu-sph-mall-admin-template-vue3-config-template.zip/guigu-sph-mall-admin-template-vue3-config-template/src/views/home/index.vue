<template>
  <div>
    <div>
      <svg-icon name="home"></svg-icon>
      首页
    </div>
  </div>
</template>

<script setup lang="ts">
// import SvgIcon from '@/components/SvgIcon/src/SvgIcon.vue'
</script>
