/*
 * @Author: 朽木白
 * @Date: 2023-02-03 15:40:02
 * @LastEditors: 1547702880@@qq.com
 * @LastEditTime: 2023-02-03 15:40:05
 * @Description: 缓存字段枚举值
 */

export const TOKEN_KEY = 'TOKEN__'

export const USER_INFO_KEY = 'USER__INFO__'
