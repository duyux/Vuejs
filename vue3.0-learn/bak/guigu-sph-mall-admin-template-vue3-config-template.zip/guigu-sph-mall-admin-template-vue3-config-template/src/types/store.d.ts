export interface UserInfo {
  userId?: string | number
  username: string
  avatar: string
  desc?: string
}
