# mocha-vue3-system
A vue3 management system

## project screenshot
![screenshot](/public/home1.png)
