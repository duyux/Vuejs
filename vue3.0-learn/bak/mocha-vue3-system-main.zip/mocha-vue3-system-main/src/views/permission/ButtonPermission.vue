<template>
  <div>{{ $t('common.tobeCoded') }}</div>
</template>
