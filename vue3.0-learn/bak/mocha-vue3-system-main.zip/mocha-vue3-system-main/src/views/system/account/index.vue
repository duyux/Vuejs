<template>
  <div class="container"></div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
const vfdRef = ref(null)
</script>

<style lang="scss">
body {
  margin: 0; /* 如果页面出现垂直滚动条，则加入此行CSS以消除之 */
}
</style>
