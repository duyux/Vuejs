<template>
  <div>我是子组件<Grandson class="p-4 m-4 border" /></div>
</template>

<script setup lang="ts">
import Grandson from './grandson.vue'
</script>
