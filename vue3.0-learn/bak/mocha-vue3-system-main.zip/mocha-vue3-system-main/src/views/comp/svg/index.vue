<template>
  <div class="container">
    <div class="page-header"><h2>SVG</h2></div>
    <i-ep-link />
    <el-card><svg-icon name="moon" color="#0094ff"></svg-icon></el-card>
  </div>
</template>

<script setup lang="ts"></script>
