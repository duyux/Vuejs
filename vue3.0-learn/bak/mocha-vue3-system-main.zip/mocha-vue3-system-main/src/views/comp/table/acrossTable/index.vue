<template>
  <div class="page-header">
    <h2>表格跨页选取数据</h2>
    <p>列表多页时，选择数据后，切换页面已选择项会清空。此组件就是保存所有页面的已选项。</p>
  </div>
</template>
