export enum RoleEnum {
  SUPER = 'super',
  USER = 'user'
}
