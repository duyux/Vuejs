# mocha-vue3-system
mocha-vue3-system是一个基于Vue3、Vite、Element Plus、Typescript、Tailwind CSS的后台管理系统模板，目标是提供轻松简单的后台开发方案。
可以使用它作为项目的启动模板，帮助你快速搭建后台管理系统，也可以作为学习的demo，尝试更多可能性。

项目仍在快速迭代中，作者会持续更新和优化，完善使用体验。


## 示例
[在线预览](http://118.89.81.22:9527/)

## 文档
目前还没有发布单独的文档，

现阶段请参考掘金专栏：https://juejin.cn/column/7226940127885869114

## 项目截图
![home1](https://github.com/lucidity99/mocha-vue3-system/assets/44628665/b54f73cd-ab9b-4500-83a9-29048b662484)

## 联系我
欢迎通过掘金联系我，或者直接发送邮件。

