<template>
  <avue-form-design style="height: 100vh;"
                    :options="options"
                    undo-redo
                    aside-left-width="270px"
                    aside-right-width="380px"></avue-form-design>
</template>

<script>

export default {
  data() {
    return {
      options: { // 可以是Object
        column: [{
          label: '单行文本',
          prop: 'input',
          type: 'input'
        }]
      },
      // options: `{ column: [{ label: '单行文本', prop: 'input', type: 'input' }] }`, // 也可以是String，用于接口请求后直接赋值
    }
  }
}
</script>
