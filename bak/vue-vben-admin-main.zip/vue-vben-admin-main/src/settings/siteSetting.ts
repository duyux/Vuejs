// github repo url
export const GITHUB_URL = 'https://github.com/anncwb/vue-vben-admin';

// vue-vben-admin-next-doc
export const DOC_URL = 'https://vvbin.cn/doc-next/';

// site url
export const SITE_URL = 'https://vvbin.cn/next/';
