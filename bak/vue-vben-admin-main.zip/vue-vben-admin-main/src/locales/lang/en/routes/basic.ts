export default {
  login: 'Login',
  errorLogList: 'Error Log',
};
