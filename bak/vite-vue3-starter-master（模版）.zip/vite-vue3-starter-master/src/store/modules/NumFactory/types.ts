export default interface NumFactoryStateTypes {
  name: string
  count: number
}
