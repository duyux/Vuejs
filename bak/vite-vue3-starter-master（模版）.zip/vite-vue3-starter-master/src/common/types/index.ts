export interface NavItem {
  path: string
  name: string
  isActive: boolean
}
