<template>
  <router-view />
</template>

<script>
export default {
  name: 'layout-block'
}
</script>
