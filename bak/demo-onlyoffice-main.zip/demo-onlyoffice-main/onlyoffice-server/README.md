# Onlyoffice Server

基于 nest 的 Onlyoffice 示例。


### 快速使用

```bash
# 安装依赖
pnpm install

# 开发
pnpm run dev

# 打包
pnpm run build
```


## License

[MIT](/LICENSE)
