# Change Log

## [v1.2.3(2017-12-26)](https://github.com/Brickies/vui/tree/v1.2.3)

### Features

- **gh-pages:** add gh-pages for vui and build v1.2.3 .
- **Makefile:** add make del and improved make deploy . [commit](https://github.com/Brickies/vui/commit/a60123150cfc994a9f0a581d63d11850ae05ab1d)


## [v1.2.4(2017-1-1)](https://github.com/Brickies/vui/tree/v1.2.4)

### Features

- **content-placeholder:** add content-placeholder component . [commit](https://github.com/Brickies/vui/commit/1399a5df2975bde63f448b47164bd061c1751fa6)
- **v-placeholder:** add v-placeholder directive . [commit](https://github.com/Brickies/vui/commit/610d0395f6926ca2f10d328102e67241547a8709)


## [v1.2.5(2017-1-3)](https://github.com/Brickies/vui/tree/v1.2.5)

### Features

- **icon:** add icon component . [commit](https://github.com/Brickies/vui/commit/fb71e1f5ff5037eed1c6b02df30126c0642ffe7d)
- **version build:** add package verison build directive . 

## [v1.2.6(2017-1-14)](https://github.com/Brickies/vui/tree/v1.2.6)

### Features

- **button** add button component . [commit](https://github.com/Brickies/vui/commit/bc0e69a337b671f7e50543047363e84f3b7d5876)

## [v1.2.7(2017-1-31)](https://github.com/Brickies/vui/tree/v1.2.7)

### Features

- **cell** add cell and cell-group component . [commit](https://github.com/Brickies/vui/commit/5bc4b65cb2560738b43cbfae24f35e8fc28f181c)

## [v1.2.8(2017-3-28)](https://github.com/Brickies/vui/tree/v1.2.8)

- **project** project version upgrade . [commit](https://github.com/Brickies/vui/commit/ea4de9730e0661eab520978a2fb8fe707c433875)