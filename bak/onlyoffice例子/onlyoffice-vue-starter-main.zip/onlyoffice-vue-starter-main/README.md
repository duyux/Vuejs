# onlyoffice-vue-starter
Preview、edit office file

[Preview Docx](https://personal.onlyoffice.com/products/files/doceditor?fileId=5473971)

It must be used with the server | [Doc Api](https://api.onlyoffice.com/editors/advanced)

![LD)~FL316(_M~VYE@}T_CJB](https://user-images.githubusercontent.com/45450994/184916548-b1c3fae9-5dea-4ea9-8166-7898f5a1cf05.jpg)
![image](https://user-images.githubusercontent.com/45450994/185038826-4ad81578-f851-42d6-8467-6aad03f87ef2.png)

