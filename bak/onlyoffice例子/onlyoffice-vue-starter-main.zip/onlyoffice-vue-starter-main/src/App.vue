<script setup lang="ts">
</script>

<template>
  <RouterView />
</template>

<style scoped>
</style>
