
declare const DocsAPI: {
    DocEditor: (id: string, config: import('./components/office/type').OnlyOfficeConfigType) => void;
};

