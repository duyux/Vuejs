## Overview

Insert into document custom fields.

It is called "Example add custom fields 2" in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Open the Plugins tab and press "Example add custom fields 2".
2. Add textQ or listQ in the corresponding tabs (type necessary text, check necessary options and press the "Save" button).
3. If you nee you can copy necessary field in the corresponding tab.
4. You can insert option into document in "Insert Option" tab (choose an option and press the "Insert" button).

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic