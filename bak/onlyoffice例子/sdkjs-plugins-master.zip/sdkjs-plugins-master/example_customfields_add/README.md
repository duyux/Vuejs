## Overview

Insert into document custom field. This plugin works in pair with plugin "Example loading custom fields".

It is called Example add custom fields in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Open the Plugins tab and press "Example add custom fields".
2. For adding simple field type your question and label in necessary fields (they are marked) and press the button "Add simple field". This field will added in current cursor position.
3. For adding simple field type your question and label in necessary fields (they are marked). For adding answer variation type it in field (marked "Type your item") and press the button "Add" (repeat it if you need add more variations). If you need remove any answer variation - select him in combo box and press the button "Remove". When field is ready press the button "Add drop down field". This field will adding in current cursor position.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic