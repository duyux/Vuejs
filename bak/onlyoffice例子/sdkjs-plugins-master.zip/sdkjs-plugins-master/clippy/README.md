## Overview

This plugin shows how to add clippy assintant in document editor.

The plugin uses the [clippy.js] is a full Javascript implementation of Microsoft Agent (AKA Clippy and friends), ready to be embedded in any website. (https://www.smore.com/clippy-js).

It is called Clippy in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Find the plugin in the Plugins tab.
2. Select any assistant.
3. Click on assistan to start random animation.