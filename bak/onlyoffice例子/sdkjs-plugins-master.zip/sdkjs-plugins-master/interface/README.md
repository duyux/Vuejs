## Overview

This plugin shows how you can change interface.

It isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Add this plugin to yourself and open any document.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic