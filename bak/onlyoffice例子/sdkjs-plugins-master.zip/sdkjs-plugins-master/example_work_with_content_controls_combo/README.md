## Overview

This plugin shows how add for content control combo box like in plugin example_autocomplete.

It is called "example_work_with_content_controls_combo" in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Open the Plugins tab and press "example_work_with_content_controls_combo" (you nee add some content controls (with tag {people} or {position}, this tags use in code plugin for example) before or after start plugin).
2. Click on content control. If plugin find necessary tag, then you will see input helper window with some options.
2. Select an option and press the "Enter" button or click to paste option value in content control.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic