## Overview

This plugin shows how to move cursor to start or end document.

It is called "Example move cursor" in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Open the Plugins tab and press "Example move cursor".
2. Press the "Start" button to move cursor to start a document.
3. Press the "Stop" button to move cursor to end a document.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic