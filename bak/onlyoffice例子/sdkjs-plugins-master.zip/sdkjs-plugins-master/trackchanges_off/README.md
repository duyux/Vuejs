## Overview

This plugin disables track changes in any document and does not allow you to enable it.

It works only in special regime (when in customization was added showReviewChanges flag).

It is without interface plugin and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Add this plugin to yourself and open document editor.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic