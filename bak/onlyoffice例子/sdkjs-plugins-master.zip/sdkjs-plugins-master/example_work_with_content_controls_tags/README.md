## Overview

This plugin shows how to work with content constrols tags.

It is called "Example work with content controls tags" in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Open the Plugins tab and press "Example work with content controls tags". You need to add some content controls into document (you can do it before or after the plugin was started). Also you need to set any tag for content controls.
2. In the field below you can see all content controls tags (press the "Refresh list" button).
3. Press the "Past "Test paste for document"" for paste text into selected content control.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic