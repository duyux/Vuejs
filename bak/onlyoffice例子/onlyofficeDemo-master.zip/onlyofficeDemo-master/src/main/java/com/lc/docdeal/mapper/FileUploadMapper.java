package com.lc.docdeal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lc.docdeal.bean.FileUpload;

public interface FileUploadMapper extends  BaseMapper<FileUpload>{

}
