package com.lc.docdeal.bean;

import java.io.Serializable;

public class  File implements Serializable {
    private static final long serialVersionUID = 1L;
    private String fileId;
    private String fileName;
    private String crateTime;
    private String updateTime;
    private String createBy;
    private String updateBy;
    private String isDel;
}
