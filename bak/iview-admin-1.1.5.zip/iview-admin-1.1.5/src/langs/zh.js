export default {
    switchLangTitle: '切换语言'
};
