export default {
    switchLangTitle: 'Switch Lang'
};
