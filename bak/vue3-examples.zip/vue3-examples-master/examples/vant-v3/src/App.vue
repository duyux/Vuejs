<template>
<!-- 和 vue-router3 一样，展示路由的组件的地方 -->
  <router-view />
</template>

<script>

export default {
  name: 'App'
}
</script>

<style lang='less' scoped>
.test {
  width: 100px;
  height: 100px;
  background-color: aquamarine;
  font-size: 20PX;
}
</style>
