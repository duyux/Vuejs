<template>
    <div>
        avator-editor
    </div>
</template>

<script>
export default {
    //
};
</script>

<style>

</style>
