export default {
    'zh-CN': {

    },
    'en-US': {

    }
};
