<!--
 * @GitHub: https://github.com/MaleWeb/vvtp
 * @version: 
 * @Author: 扫地盲僧
 * @Date: 2022-01-24 16:44:58
 * @LastEditors: BlindMonk
 * @LastEditTime: 2022-01-24 17:28:57
-->
<script setup lang="ts">
import Header from "@/components/Header.vue"
import ReadMe from '../../README.md'
</script>

<template>
    <div>
        <!-- <Header /> -->
        <div class="w-full flex justify-center">
            <ReadMe />
        </div>
    </div>
</template>

<style lang="less" scoped>
</style>
