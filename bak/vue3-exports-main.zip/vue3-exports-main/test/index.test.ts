import { expect, it, test, describe } from 'vitest'

describe('basic', () => {
	it('shared', () => {
		expect(1 + 1).toBe(2)
	})
})
