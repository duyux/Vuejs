<script lang="ts" setup>
import Counter from './components/Counter.vue'
</script>

<template>
	<Counter />
</template>
